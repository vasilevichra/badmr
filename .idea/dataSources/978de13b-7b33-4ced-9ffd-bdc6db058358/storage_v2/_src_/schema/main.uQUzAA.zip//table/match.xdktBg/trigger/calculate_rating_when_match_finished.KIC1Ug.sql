CREATE TRIGGER calculate_rating_when_match_finished
    AFTER UPDATE
    ON match
    WHEN new.finished = 1
     AND old.finished != 1
     AND NOT EXISTS (SELECT 1 FROM rating WHERE match_id = new.id)
     AND ((SELECT count(lost_1_by)
           FROM game
           WHERE match_id = new.id) = (SELECT cast(value AS int)
                                       FROM settings
                                       WHERE name = 'wins')
       OR (SELECT count(lost_2_by)
           FROM game
           WHERE match_id = new.id) = (SELECT cast(value AS int)
                                       FROM settings
                                       WHERE name = 'wins'))
BEGIN
    INSERT INTO rating (user_id, match_id, previous, delta)
    WITH last AS (
        SELECT (SELECT previous + coalesce(delta, 0)
                FROM rating
                WHERE user_id = new.user_1_id
                ORDER BY id DESC
                LIMIT 1) AS p1,
               (SELECT previous + coalesce(delta, 0)
                FROM rating
                WHERE user_id = new.user_2_id
                ORDER BY id DESC
                LIMIT 1) AS p2,
               (SELECT previous + coalesce(delta, 0)
                FROM rating
                WHERE user_id = new.user_3_id
                ORDER BY id DESC
                LIMIT 1) AS p3,
               (SELECT previous + coalesce(delta, 0)
                FROM rating
                WHERE user_id = new.user_4_id
                ORDER BY id DESC
                LIMIT 1) AS p4,
               (SELECT count(lost_1_by)
                FROM game
                WHERE match_id = new.id) AS lost_1,
               (SELECT count(lost_2_by)
                FROM game
                WHERE match_id = new.id) AS lost_2,
               (SELECT cast(value AS int)
                FROM settings
                WHERE name = 'wins') AS wins
    ),
    calc AS (
        SELECT round(p1, 1) AS r1,
               round(p2, 1) AS r2,
               round(p3, 1) AS r3,
               round(p4, 1) AS r4,
               -- дельты для обеих ролей: diff1 = avg(3,4) - avg(1,2) —
               -- на столько команда 3/4 сильнее; при её победе её игроки
               -- получают +(100 - diff1)/10, при проигрыше — наоборот
               CASE WHEN (p3 + p4) / 2.0 - (p1 + p2) / 2.0 >= 100 THEN 0
                    ELSE round((100 - ((p3 + p4) / 2.0 - (p1 + p2) / 2.0)) / 10.0, 1) END  AS win34_delta,
               CASE WHEN (p3 + p4) / 2.0 - (p1 + p2) / 2.0 >= 100 THEN 0
                    ELSE round((100 - ((p3 + p4) / 2.0 - (p1 + p2) / 2.0)) / -10.0, 1) END AS lose12_delta,
               CASE WHEN (p1 + p2) / 2.0 - (p3 + p4) / 2.0 >= 100 THEN 0
                    ELSE round((100 - ((p1 + p2) / 2.0 - (p3 + p4) / 2.0)) / 10.0, 1) END  AS win12_delta,
               CASE WHEN (p1 + p2) / 2.0 - (p3 + p4) / 2.0 >= 100 THEN 0
                    ELSE round((100 - ((p1 + p2) / 2.0 - (p3 + p4) / 2.0)) / -10.0, 1) END AS lose34_delta,
               lost_1 = wins AS team_1_lost
        FROM last
    )
    SELECT new.user_1_id, new.id, r1, CASE WHEN team_1_lost THEN lose12_delta ELSE win12_delta END
    FROM calc
    UNION ALL
    SELECT new.user_2_id, new.id, r2, CASE WHEN team_1_lost THEN lose12_delta ELSE win12_delta END
    FROM calc
    UNION ALL
    SELECT new.user_3_id, new.id, r3, CASE WHEN team_1_lost THEN win34_delta ELSE lose34_delta END
    FROM calc
    UNION ALL
    SELECT new.user_4_id, new.id, r4, CASE WHEN team_1_lost THEN win34_delta ELSE lose34_delta END
    FROM calc;
END;

