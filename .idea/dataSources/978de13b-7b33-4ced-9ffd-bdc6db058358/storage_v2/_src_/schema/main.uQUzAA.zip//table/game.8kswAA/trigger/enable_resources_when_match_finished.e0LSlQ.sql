CREATE TRIGGER enable_resources_when_match_finished
    AFTER INSERT
    ON game
    WHEN ((SELECT count(g.lost_1_by)
           FROM game g
                    JOIN match m ON m.id = g.match_id
           WHERE g.match_id = new.match_id) = (SELECT cast(value AS int)
                                               FROM settings
                                               WHERE name = 'wins') OR (SELECT count(g.lost_2_by)
                                                                        FROM game g
                                                                        WHERE g.match_id = new.match_id) = (SELECT cast(value AS int)
                                                                                                            FROM settings
                                                                                                            WHERE name = 'wins'))
BEGIN
    UPDATE match SET finished = 1 WHERE id = new.match_id;

    UPDATE court SET available = 1 WHERE id IN (SELECT court_id FROM match WHERE id = new.match_id);

    UPDATE tournament_user
    SET available = 1
    WHERE user_id IN (SELECT user_1_id FROM match WHERE id = new.match_id)
       OR user_id IN (SELECT user_2_id FROM match WHERE id = new.match_id)
       OR user_id IN (SELECT user_3_id FROM match WHERE id = new.match_id)
       OR user_id IN (SELECT user_4_id FROM match WHERE id = new.match_id);
END;

