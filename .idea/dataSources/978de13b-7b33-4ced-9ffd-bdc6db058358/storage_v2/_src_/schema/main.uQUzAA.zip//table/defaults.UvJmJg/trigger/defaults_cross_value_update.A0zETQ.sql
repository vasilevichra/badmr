CREATE TRIGGER defaults_cross_value_update
    AFTER UPDATE OF value ON defaults
BEGIN
    SELECT RAISE(ABORT, 'defaults.value: max_point должен быть больше game_point')
    WHERE NEW.name IN ('max_point', 'game_point')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'max_point')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'game_point');
    SELECT RAISE(ABORT, 'defaults.value: B_max должен быть больше C_max')
    WHERE NEW.name IN ('B_max', 'C_max')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'B_max')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'C_max');
    SELECT RAISE(ABORT, 'defaults.value: C_max должен быть больше D_max')
    WHERE NEW.name IN ('C_max', 'D_max')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'C_max')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'D_max');
    SELECT RAISE(ABORT, 'defaults.value: D_max должен быть больше E_max')
    WHERE NEW.name IN ('D_max', 'E_max')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'D_max')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'E_max');
    SELECT RAISE(ABORT, 'defaults.value: E_max должен быть больше F_max')
    WHERE NEW.name IN ('E_max', 'F_max')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'E_max')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'F_max');
    SELECT RAISE(ABORT, 'defaults.value: F_max должен быть больше G_max')
    WHERE NEW.name IN ('F_max', 'G_max')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'F_max')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'G_max');
    SELECT RAISE(ABORT, 'defaults.value: G_max должен быть больше H_max')
    WHERE NEW.name IN ('G_max', 'H_max')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'G_max')
        <= (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'H_max');
    SELECT RAISE(ABORT, 'defaults.value: r_max должен быть не меньше r_min')
    WHERE NEW.name IN ('r_max', 'r_min')
      AND (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'r_max')
        < (SELECT CAST(value AS INTEGER) FROM defaults WHERE name = 'r_min');
END;

