CREATE VIEW settings AS
SELECT d.name, coalesce(s.value, d.value) AS value
FROM defaults d
         LEFT OUTER JOIN tournament_settings s ON s.defaults_id = d.id
         LEFT OUTER JOIN tournament t ON s.tournament_id = t.id AND t.current = 1 AND t.available = 1;

