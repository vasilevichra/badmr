CREATE VIEW delta_week AS
SELECT u.id AS user_id, u.lastname || ' ' || u.firstname AS name, round(sum(r.delta), 1) AS sum
FROM rating r
         JOIN match m ON m.id = r.match_id AND date(m.created_at) BETWEEN date('now', 'weekday 0', '-6 day') AND date('now', 'weekday 0')
         JOIN user u ON u.id = r.user_id
GROUP BY r.user_id
ORDER BY sum DESC;

