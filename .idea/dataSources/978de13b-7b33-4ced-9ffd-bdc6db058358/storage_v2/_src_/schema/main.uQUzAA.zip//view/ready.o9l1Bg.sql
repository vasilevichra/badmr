CREATE VIEW ready AS
SELECT u.lastname || ' ' || u.firstname                                                                                                                AS name,
       u.id                                                                                                                                            AS user_id,
       round((coalesce(r.previous, 0) + coalesce(r.delta, 0)), 1)                                                                                      AS rating,
       count(DISTINCT m.id)                                                                                                                            AS matches,
       u.id IN (SELECT DISTINCT u_id
                FROM (SELECT u_id
                      FROM (SELECT user_1_id AS u_id
                            FROM match
                            ORDER BY id DESC
                            LIMIT (SELECT sum(n) courts
                                   FROM (SELECT count(id) n FROM court WHERE available = 1 UNION SELECT count(id) n FROM match WHERE finished = 0)))
                      UNION ALL
                      SELECT u_id
                      FROM (SELECT user_2_id AS u_id
                            FROM match
                            ORDER BY id DESC
                            LIMIT (SELECT sum(n) courts
                                   FROM (SELECT count(id) n FROM court WHERE available = 1 UNION SELECT count(id) n FROM match WHERE finished = 0)))
                      UNION ALL
                      SELECT u_id
                      FROM (SELECT user_3_id AS u_id
                            FROM match
                            ORDER BY id DESC
                            LIMIT (SELECT sum(n) courts
                                   FROM (SELECT count(id) n FROM court WHERE available = 1 UNION SELECT count(id) n FROM match WHERE finished = 0)))
                      UNION ALL
                      SELECT u_id
                      FROM (SELECT user_4_id AS u_id
                            FROM match
                            ORDER BY id DESC
                            LIMIT (SELECT sum(n) courts
                                   FROM (SELECT count(id) n FROM court WHERE available = 1 UNION SELECT count(id) n FROM match WHERE finished = 0))))) AS played
FROM tournament as t
         JOIN tournament_user AS tu ON tu.tournament_id = t.id AND tu.available = 1 AND tu.archived = 0
         JOIN user AS u ON u.id = tu.user_id
         LEFT JOIN match m ON u.id IN (m.user_1_id, m.user_2_id, m.user_3_id, m.user_4_id)
         JOIN (SELECT max(id) AS id, user_id, previous, delta FROM rating GROUP BY user_id) AS r ON r.user_id = u.id
         JOIN defaults d ON d.name = 'matches'
         LEFT OUTER JOIN tournament_settings s ON s.defaults_id = d.id AND s.tournament_id = t.id
WHERE t.current = 1
  AND t.available = 1
GROUP BY u.id
HAVING CASE -- сыгранных матчей меньше, чем в ограничении для турнира
           WHEN s.value > 0 THEN count(DISTINCT m.id) < s.value
           WHEN d.value > 0 THEN count(DISTINCT m.id) < d.value
           ELSE 1 END
ORDER BY played, matches DESC;

