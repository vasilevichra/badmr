CREATE TRIGGER calculate_rating_lost_1
    AFTER INSERT
    ON game
    WHEN new.lost_1_by IS NOT NULL
BEGIN
    INSERT INTO rating (user_id, game_id, previous, delta)
    VALUES ((SELECT u.id
             FROM game g
                      JOIN match m ON m.id = g.match_id
                      JOIN user u ON u.id = m.user_1_id
             WHERE g.id = new.id
             LIMIT 1),
            new.id,
            (SELECT round((p + coalesce(d, 0)), 1)
             FROM (SELECT r.previous AS p, r.delta AS d, max(r.id)
                   FROM game g
                            JOIN match m ON m.id = g.match_id
                            JOIN user u ON u.id = m.user_1_id
                            JOIN rating r ON u.id = r.user_id
                   WHERE g.id = new.id
                   GROUP BY u.id)),
            (SELECT round(((100 - rating_win + rating_lose) / (-10)), 1)
             FROM (SELECT (sum(rate1) / 2.0) AS rating_win
                   FROM (SELECT (r1.previous + coalesce(r1.delta, 0)) AS rate1, max(r1.id)
                         FROM game g1
                                  JOIN match m1 ON m1.id = g1.match_id
                                  JOIN user u1 ON u1.id IN (m1.user_3_id, m1.user_4_id)
                                  JOIN rating r1 ON r1.user_id = u1.id
                         WHERE g1.id = new.id
                         GROUP BY u1.id)),
                  (SELECT (sum(rate2) / 2.0) AS rating_lose
                   FROM (SELECT (r2.previous + coalesce(r2.delta, 0)) AS rate2, max(r2.id)
                         FROM game g2
                                  JOIN match m2 ON m2.id = g2.match_id
                                  JOIN user u2 ON u2.id IN (m2.user_1_id, m2.user_2_id)
                                  JOIN rating r2 ON r2.user_id = u2.id
                         WHERE g2.id = new.id
                         GROUP BY u2.id))
             LIMIT 1)),
           ((SELECT u.id
             FROM game g
                      JOIN match m ON m.id = g.match_id
                      JOIN user u ON u.id = m.user_2_id
             WHERE g.id = new.id
             LIMIT 1),
            new.id,
            (SELECT round((p + coalesce(d, 0)), 1)
             FROM (SELECT r.previous AS p, r.delta AS d, max(r.id)
                   FROM game g
                            JOIN match m ON m.id = g.match_id
                            JOIN user u ON u.id = m.user_2_id
                            JOIN rating r ON u.id = r.user_id
                   WHERE g.id = new.id
                   GROUP BY u.id)),
            (SELECT round(((100 - rating_win + rating_lose) / (-10)), 1)
             FROM (SELECT (sum(rate1) / 2.0) AS rating_win
                   FROM (SELECT (r1.previous + coalesce(r1.delta, 0)) AS rate1, max(r1.id)
                         FROM game g1
                                  JOIN match m1 ON m1.id = g1.match_id
                                  JOIN user u1 ON u1.id IN (m1.user_3_id, m1.user_4_id)
                                  JOIN rating r1 ON r1.user_id = u1.id
                         WHERE g1.id = new.id
                         GROUP BY u1.id)),
                  (SELECT (sum(rate2) / 2.0) AS rating_lose
                   FROM (SELECT (r2.previous + coalesce(r2.delta, 0)) AS rate2, max(r2.id)
                         FROM game g2
                                  JOIN match m2 ON m2.id = g2.match_id
                                  JOIN user u2 ON u2.id IN (m2.user_1_id, m2.user_2_id)
                                  JOIN rating r2 ON r2.user_id = u2.id
                         WHERE g2.id = new.id
                         GROUP BY u2.id))
             LIMIT 1)),
           ((SELECT u.id
             FROM game g
                      JOIN match m ON m.id = g.match_id
                      JOIN user u ON u.id = m.user_3_id
             WHERE g.id = new.id
             LIMIT 1),
            new.id,
            (SELECT round((p + coalesce(d, 0)), 1)
             FROM (SELECT r.previous AS p, r.delta AS d, max(r.id)
                   FROM game g
                            JOIN match m ON m.id = g.match_id
                            JOIN user u ON u.id = m.user_3_id
                            JOIN rating r ON u.id = r.user_id
                   WHERE g.id = new.id
                   GROUP BY u.id)),
            (SELECT round(((100 - rating_win + rating_lose) / 10), 1)
             FROM (SELECT (sum(rate1) / 2.0) AS rating_win
                   FROM (SELECT (r1.previous + coalesce(r1.delta, 0)) AS rate1, max(r1.id)
                         FROM game g1
                                  JOIN match m1 ON m1.id = g1.match_id
                                  JOIN user u1 ON u1.id IN (m1.user_3_id, m1.user_4_id)
                                  JOIN rating r1 ON r1.user_id = u1.id
                         WHERE g1.id = new.id
                         GROUP BY u1.id)),
                  (SELECT (sum(rate2) / 2.0) AS rating_lose
                   FROM (SELECT (r2.previous + coalesce(r2.delta, 0)) AS rate2, max(r2.id)
                         FROM game g2
                                  JOIN match m2 ON m2.id = g2.match_id
                                  JOIN user u2 ON u2.id IN (m2.user_1_id, m2.user_2_id)
                                  JOIN rating r2 ON r2.user_id = u2.id
                         WHERE g2.id = new.id
                         GROUP BY u2.id))
             LIMIT 1)),
           ((SELECT u.id
             FROM game g
                      JOIN match m ON m.id = g.match_id
                      JOIN user u ON u.id = m.user_4_id
             WHERE g.id = new.id
             LIMIT 1),
            new.id,
            (SELECT round((p + coalesce(d, 0)), 1)
             FROM (SELECT r.previous AS p, r.delta AS d, max(r.id)
                   FROM game g
                            JOIN match m ON m.id = g.match_id
                            JOIN user u ON u.id = m.user_4_id
                            JOIN rating r ON u.id = r.user_id
                   WHERE g.id = new.id
                   GROUP BY u.id)),
            (SELECT round(((100 - rating_win + rating_lose) / 10), 1)
             FROM (SELECT (sum(rate1) / 2.0) AS rating_win
                   FROM (SELECT (r1.previous + coalesce(r1.delta, 0)) AS rate1, max(r1.id)
                         FROM game g1
                                  JOIN match m1 ON m1.id = g1.match_id
                                  JOIN user u1 ON u1.id IN (m1.user_3_id, m1.user_4_id)
                                  JOIN rating r1 ON r1.user_id = u1.id
                         WHERE g1.id = new.id
                         GROUP BY u1.id)),
                  (SELECT (sum(rate2) / 2.0) AS rating_lose
                   FROM (SELECT (r2.previous + coalesce(r2.delta, 0)) AS rate2, max(r2.id)
                         FROM game g2
                                  JOIN match m2 ON m2.id = g2.match_id
                                  JOIN user u2 ON u2.id IN (m2.user_1_id, m2.user_2_id)
                                  JOIN rating r2 ON r2.user_id = u2.id
                         WHERE g2.id = new.id
                         GROUP BY u2.id))
             LIMIT 1));
END;

