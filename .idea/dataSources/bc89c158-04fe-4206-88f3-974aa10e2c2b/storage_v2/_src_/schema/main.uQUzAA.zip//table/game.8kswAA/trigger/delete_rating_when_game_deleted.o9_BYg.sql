CREATE TRIGGER delete_rating_when_game_deleted
    AFTER DELETE
    ON game
BEGIN
    DELETE FROM rating WHERE game_id = old.id;
END;

