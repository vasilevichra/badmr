CREATE VIEW archived AS
SELECT u.id AS id, u.lastname || ' ' || u.firstname AS name, u.sex AS sex, up.pic AS pic, c.name AS city
FROM user u
         JOIN city c ON c.id = u.city_id
         JOIN tournament_user tu ON u.id = tu.user_id
         JOIN tournament t ON t.id = tu.tournament_id AND t.current = 1
         LEFT OUTER JOIN user_pic up ON up.user_id = u.id
WHERE tu.archived = 1;

