CREATE TRIGGER disable_court_and_tournament_users_by_match_created
    AFTER INSERT
    ON match
BEGIN
    UPDATE court SET available = 0 WHERE id = new.court_id;

    UPDATE tournament_user
    SET available = 0
    WHERE user_id IN (new.user_1_id, new.user_2_id, new.user_3_id, new.user_4_id)
      AND tournament_id IN (SELECT id FROM tournament AS t WHERE t.available = 1);
END;

