CREATE TRIGGER enable_court_and_tournament_users_by_match_deleted
    AFTER DELETE
    ON match
BEGIN
    UPDATE court SET available = 1 WHERE id = old.court_id;

    UPDATE tournament_user
    SET available = 1
    WHERE user_id IN (old.user_1_id, old.user_2_id, old.user_3_id, old.user_4_id)
      AND tournament_id IN (SELECT id FROM tournament AS t WHERE t.available = 1);
END;

