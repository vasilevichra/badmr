CREATE VIEW players AS
SELECT u.id                                                       AS id,
       u.lastname || ' ' || u.firstname                           AS name,
       round((coalesce(r.previous, 0) + coalesce(r.delta, 0)), 0) AS rating,
       dt.sum                                                     AS delta_today,
       dw.sum                                                     AS delta_week,
       dm.sum                                                     AS delta_month,
       u.sex                                                      AS sex,
       up.pic                                                     AS pic,
       count(DISTINCT m.id)                                       AS matches,
       c.name                                                     AS city,
       u.birthday                                                 AS birthday,
       CASE WHEN tu.id IS NULL THEN 0 ELSE 1 END                  AS registered,
       coalesce(tu.available, 0)                                  AS enabled,
       tu.archived                                                AS archived
FROM user u
         JOIN city c ON c.id = u.city_id
         LEFT OUTER JOIN tournament_user tu ON u.id = tu.user_id
         LEFT OUTER JOIN tournament t ON t.id = tu.tournament_id AND t.current = 1
         LEFT JOIN match m ON u.id IN (m.user_1_id, m.user_2_id, m.user_3_id, m.user_4_id)
         LEFT OUTER JOIN (SELECT max(id) AS id, user_id, previous, delta FROM rating GROUP BY user_id) AS r ON r.user_id = u.id
         LEFT OUTER JOIN delta_today dt ON dt.user_id = u.id
         LEFT OUTER JOIN delta_week dw ON dw.user_id = u.id
         LEFT OUTER JOIN delta_month dm ON dm.user_id = u.id
         LEFT OUTER JOIN user_pic up ON up.user_id = u.id
WHERE tu.archived IS NULL
   OR tu.archived = 0
GROUP BY u.id;

